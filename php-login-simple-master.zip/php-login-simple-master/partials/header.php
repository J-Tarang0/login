<header>
  <a href="/php-login">Your App Name</a>
</header>
